package reducer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

import java.io.IOException;

public class OrderReducer
        extends Reducer <Text, Text , Text, Text > {
    private MultipleOutputs <Text, Text > multipleOutputs;

    @Override
    protected void setup(Context context) {
        multipleOutputs = new MultipleOutputs <>(context);
    }

    @Override
    protected void reduce(Text key, Iterable <Text> values ,
                          Context context) throws IOException, InterruptedException {
        //输入：<委托时间, 委托价格 委托数量 委托方向 委托类型 委托索引 "0" "2">

        //根据标识符判断OrderType
        for(Text value : values){
            //市价单 输出为"MarketOrder"
            if (value.toString().equals("1")) {
                multipleOutputs.write("MarketOrder", key, new Text());
            }
            //限价单 输出为"LimitedOrder"
            else if (value.toString().equals("2")){
                multipleOutputs.write("LimitedOrder", key, new Text());
            }
            //本方最优"U" 输出为"SpecOrder"
            else{
                multipleOutputs.write("SpecOrder", key, new Text());
            }
        }

    }

    @Override
    protected void cleanup(Context context)
            throws IOException , InterruptedException {
        multipleOutputs.close();
    }
}