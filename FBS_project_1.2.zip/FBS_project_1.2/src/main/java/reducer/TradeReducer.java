package reducer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

import java.io.IOException;

public class TradeReducer
        extends Reducer <Text, Text , Text, Text > {
    private MultipleOutputs <Text, Text > multipleOutputs;

    @Override
    protected void setup(Context context) {
        multipleOutputs = new MultipleOutputs <>(context);
    }

    @Override
    protected void reduce(Text key, Iterable <Text> values ,
                          Context context) throws IOException, InterruptedException {
        // 输入：<成交类别， 委托时间 委托价格 委托数量 买方索引 卖方索引>

        //根据标识符判断成交类型（成交/撤销）不同处理
        if (key.toString().equals("F")) { //成交单(成交时间不需写进去)，需要用委托时间
            for(Text value: values) {
                String[] split = value.toString().split(",");//委托时间 委托价格 委托数量 买方索引 卖方索引
                //每单成交单含有两个委托索引，分别为'买方'和'卖方'
                //在处理时将每个成交单拆为两行输出，因为在'市价最低成交档位K'判断时不需要判断买卖方
                //"买方委托索引, 价格"
                //"卖方委托索引, 价格"
                Text buy = new Text(split[3] + "," + split[1]);//买方委托索引+价格
                Text sale = new Text(split[4] + "," + split[1]);//卖方委托索引+价格
                multipleOutputs.write("Trade", buy , new Text());
                multipleOutputs.write("Trade", sale, new Text());
            }
        }

        else { //撤销单(成交时间需写进去) K=4
            for(Text value: values) {
                String[] split = value.toString().split(",");//委托时间 委托价格 委托数量 买方索引 卖方索引
                if(split[3].equals("0")){ //买方委托索引=0，即买方撤单
                    Text out = new Text(split[0] + "," + split[1]  + "," + split [2] + "," + "2"
                            + "," + "2" + "," + split[4] +","+ "0" + "," + "1");//已知撤单中不存在市价单
                    multipleOutputs.write("Cancel", out, new Text());
                }
                else{//卖方委托索引=0，即卖方撤单
                    Text out = new Text(split[0] + "," + split[1]  + "," + split [2] + "," + "1"
                            + "," + "2" + "," + split[3] +","+ "0" + "," + "1");//已知撤单中不存在市价单
                    multipleOutputs.write("Cancel", out, new Text());
                }
            }
        }

    }

    @Override
    protected void cleanup(Context context)
            throws IOException , InterruptedException {
        multipleOutputs.close();
    }
}
