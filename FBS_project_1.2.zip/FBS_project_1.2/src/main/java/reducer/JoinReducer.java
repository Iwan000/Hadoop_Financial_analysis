package reducer;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class JoinReducer extends Reducer<Text, Text, Text, Text>{
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        // 输入：两种输入
        //      市价委托：<委托索引, 委托价格 委托数量 委托时间 买卖方向 Order_type + " o"> ('o' 为标识符)
        //      成交   ：<委托索引, 成交价格 + " t">('t' 为标识符)

        String order = "";
        //创建价格表，存储不同价格
        ArrayList<Double> prices = new ArrayList<>();
        int K = 0;//K值
        boolean t = false;//标识：记录该单号是否存在市价委托，默认不存在：false

        //key为委托索引
        for (Text value : values) {
            String s = value.toString();

            // 提取出辅助字段("o" 或者 "t")
            char tableId = s.charAt(s.length() - 1);

            // 提取出其他字段
            String fields = s.substring(0, s.length() - 2);

            // 根据辅助字段的值判断属于哪个表：
                //1.trade成交单
                if (tableId == 't'){
                    //提取价格
                    double price = Double.parseDouble(fields.split(",")[0]);
                    //如果价格在表中不存在，加入该新价格
                    if(!prices.contains(price)){
                        prices.add(price);
                    }
                }
                //2.order委托市价单
                else if(tableId == 'o'){
                    t = true;//更改市价标识为true，即存在市价委托
                    order = fields;//记录市价数据，供后续输出
                }
        }

        //如果存在市价委托，则在以下程序输出为市价文件
        //如果不存在市价委托，则该成交为限价成交，不输出
        if(t){
            K = prices.size();//表中价格数量即为最低成交档位
            //委托时间 委托价格 委托数量 买卖方向 委托类型 委托索引 K 成交类别
            //  key = "委托索引 委托价格 委托数量 委托时间" 买卖方向 1(OrderType) K(MARKET_OREDER_TYPE) 2(CANCEL_TYPE)
            context.write(new Text(order+",1,"+key), new Text(K + ",2,"));
        }
    }
}
