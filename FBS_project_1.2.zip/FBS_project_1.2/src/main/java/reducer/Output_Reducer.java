package reducer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.Text;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;


public class Output_Reducer extends Reducer<Text, Text, Text, Text>{
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException{
        //同一时间下不同的订单
        // values示例：9.490000,3000,2,2,133691,0,2
        TreeMap<IntWritable,Text> tradeOrder = new TreeMap<>();
        TreeMap<IntWritable,Text> cancelOrder = new TreeMap<>();
        String time = key.toString().substring(8,16);// key = 20190102093000000
        //2019-01-02 09:30:00.000000
        // time = 09300000

        // 定义输入字符串的格式
        SimpleDateFormat inputFormat = new SimpleDateFormat("HHmmssSS");

        // 将输入字符串解析为Date对象
        Date date = null;
        try {
            date = inputFormat.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        // 定义输出字符串的格式
        SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ss.SS");

        // 格式化Date对象为字符串
        String outputTime = outputFormat.format(date);
        Text timestamp = new Text("2019-01-02 " + outputTime +"0000" );


        //考虑同一时间委托并撤单的情况(共6单)
        //即在同一时间有两个orderid，分别是委托单(cancelType = 2)和撤单(cancelType = 1)
        for (Text value: values){
            String[] info = value.toString().split(",");
            IntWritable orderId = new IntWritable(Integer.parseInt(info[4]));
            if (Integer.parseInt(info[6]) == 2) { //委托单存在trade
                tradeOrder.put(orderId, new Text(value));
            } else if (Integer.parseInt(info[6]) == 1) { //撤单
                cancelOrder.put(orderId,new Text(value));
            }
        }

        //委托单先输出
        for (Map.Entry<IntWritable, Text> entry : tradeOrder.entrySet()) {
            context.write(timestamp, entry.getValue());
        }

        //撤单后输出
        for (Map.Entry<IntWritable, Text> entry : cancelOrder.entrySet()) {
            context.write(timestamp, entry.getValue());
        }

    }
}
