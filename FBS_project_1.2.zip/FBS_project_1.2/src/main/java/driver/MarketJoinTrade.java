package driver;

import mapper.MarketJoinMapper;
//import mapper.ReduceJoinOrderMapper;
//import mapper.ReduceJoinTradeMapper;
import mapper.TradeJoinMapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import reducer.JoinReducer;
//import reducer.ReduceJoinReducer;

import java.io.IOException;

public class MarketJoinTrade {
    public static void MarketJoinTrade() throws IOException, InterruptedException, ClassNotFoundException {
        // 基本参数
        Configuration conf = new Configuration();
        conf.set("mapreduce.output.textoutputformat.separator", ",");
        Job job = Job.getInstance(conf, "ReduceJoin");
        job.setJarByClass(MarketJoinTrade.class);

        // 设置市价单输入路径和对应的MarketJoinMapper处理逻辑及输出类型
        MultipleInputs.addInputPath(job, new Path("/data/output/Order/MarketOrder-r-00000")
                , TextInputFormat.class, MarketJoinMapper.class);
        // 设置成交单输入路径和对应的TradeJoinMapper处理逻辑及输出类型
        MultipleInputs.addInputPath(job, new Path("/data/output/Trade/Trade-r-00000")
                , TextInputFormat.class, TradeJoinMapper.class);
//        MultipleInputs.addInputPath(job, new Path("data/output/Trade/Cancel-r-00000")
//                , TextInputFormat.class, CancelJoinMapper.class);

        // 设置Reduce处理逻辑及输出类型
        job.setReducerClass(JoinReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        // 设置输出路径
        FileOutputFormat.setOutputPath(job, new Path("/data/output/MarketFinal"));

        // 提交任务并等待完成
        job.waitForCompletion(true);
    }
}
