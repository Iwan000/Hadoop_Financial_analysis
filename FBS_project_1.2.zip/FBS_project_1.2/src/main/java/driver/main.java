package driver;

public class main {
    public static void main(String[] args) throws Exception {
        long startTime, endTime;
        startTime = System.nanoTime();

        //按顺序按组执行，因为后续组别需要用到前置文件

        Filter_order.Filter_order();// 委托单过滤

        Filter_trade.Filter_trade();// 成交/取消单过滤

        MarketJoinTrade.MarketJoinTrade();// 市价成交委托join

        Output_Driver.Output_Driver();// 合并输出文件

        endTime = System.nanoTime();

        System.out.println(endTime-startTime);
    }
}
