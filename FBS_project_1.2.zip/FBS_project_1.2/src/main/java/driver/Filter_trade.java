package driver;

import mapper.Filter_Trade_Mapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import reducer.TradeReducer;
//import reducer.TradeReducer2;


//过滤出所需要的数据
public class Filter_trade {

    public static void Filter_trade() throws Exception {
        // 基本参数
        Configuration conf = new Configuration();
        conf.set("mapreduce.output.textoutputformat.separator", ",");
        Job job = Job.getInstance(conf, "Filter");
        job.setJarByClass(Filter_order.class);

        // Map Reduce类指定
        job.setMapperClass(Filter_Trade_Mapper.class);
        job.setReducerClass(TradeReducer.class);
        // 输出key value格式设置
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        // InputPath,OutputPath指定
        FileInputFormat.addInputPath(job, new Path("/data/origin_data/am_hq_trade_spot.txt"));
        FileInputFormat.addInputPath(job, new Path("/data/origin_data/pm_hq_trade_spot.txt"));
        FileOutputFormat.setOutputPath(job, new Path("/data/output/Trade"));

        // Multiple Outputs设置，分为两个文件，Trade（成交单），Cancel（取消单）
        MultipleOutputs.addNamedOutput(job, "Trade", TextOutputFormat.class, Text.class, Text.class);
        MultipleOutputs.addNamedOutput(job, "Cancel", TextOutputFormat.class, Text.class, Text.class);

        // 等待Map Reduce完成，输出文件,供后续流程使用
        job.waitForCompletion(true);
    }
}
