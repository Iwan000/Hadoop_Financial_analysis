package driver;

import mapper.Output_Mapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import reducer.Output_Reducer;

public class Output_Driver {

    public static void Output_Driver() throws Exception{
        // 基本参数
        Configuration conf = new Configuration();
        conf.set("mapreduce.output.textoutputformat.separator",",");
        Job job = Job.getInstance(conf,"Output");
        job.setJarByClass(Output_Driver.class);

        // Map Reduce类指定
        job.setMapperClass(Output_Mapper.class);
        job.setReducerClass(Output_Reducer.class);
        //设置Reducer输出类型
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        // InputPath,OutputPath指定
        FileInputFormat.addInputPath(job,new Path("/data/output/Order/LimitedOrder-r-00000"));//限价单(包括撤单)
        FileInputFormat.addInputPath(job,new Path("/data/output/MarketFinal/part-r-00000"));//市价委托单(已标记)
        FileInputFormat.addInputPath(job,new Path("/data/output/Trade/Cancel-r-00000"));//撤单数据
        FileOutputFormat.setOutputPath(job, new Path("/data/output/Output.txt"));

        // 提交任务并等待完成
        job.waitForCompletion(true);
    }
}
