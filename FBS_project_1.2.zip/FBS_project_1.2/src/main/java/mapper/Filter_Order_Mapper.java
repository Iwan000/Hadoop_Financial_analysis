package  mapper;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Filter_Order_Mapper extends Mapper<LongWritable, Text, Text, Text> {
    private Text filtered = new Text();

    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        //对逐行数据按"\t"分离
        String Line = value.toString();
        String[] split = Line.split("\t");

        if( (!split[8].equals("000001") ) ||//提取平安银行数据
                // 过滤出所需时间段（连续竞价阶段）数据
                (Integer.parseInt(split[12].substring(8)) < 93000000) ||//连续竞价前
                ((Integer.parseInt(split[12].substring(8)) > 113000000)&&//午间停盘
                    (Integer.parseInt(split[12].substring(8)) < 130000000) )||
                (Integer.parseInt(split[12].substring(8)) > 145700000)){//收盘后
            return;
        }
        else {//筛选出平安银行中9:30-11:30的订单
            //委托索引(7) 委托价格(10) 委托数量(11) 委托时间(12) 买卖方向(13) 委托类型(14)
            filtered.set(split[12] + ","+ split[10] + "," + split[11] + "," + split[13]
                    +"," + split[14] + "," + split[7] + "," + "0" + "," + "2");
            context.write( filtered, new Text(split[14])); //...+Order_type(委托类别作为value)
        }
    }
}

