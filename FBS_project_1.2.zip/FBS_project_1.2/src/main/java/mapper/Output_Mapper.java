package mapper;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.Arrays;

public class Output_Mapper extends Mapper <LongWritable, Text, Text, Text> {


    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] values = value.toString().split(",");
        values[1] = values[1].substring(0,5);//委托价格格式标准化
        //1.已标记的市价委托单(无撤单)
        //2.所有撤单(限价单)
        //3.所有限价单

        // 20190102093613610,10.300000,1000,2,2,820735,0,2,
        // 20190102094711690,0.000000,1800,1,1,1568874,1,2,
        Text TIMESTAMP = new Text(values[0]);

        context.write(TIMESTAMP,new Text(String.join(",", Arrays.copyOfRange(values,1,8))));
        //输出结果
        //<委托时间, 委托价格 委托数量 买卖方向 委托类型 委托索引 K 成交类别>
    }
}
