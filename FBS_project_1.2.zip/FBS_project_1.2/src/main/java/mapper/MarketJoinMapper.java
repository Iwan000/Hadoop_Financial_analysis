package mapper;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.Arrays;

public class MarketJoinMapper extends Mapper<LongWritable, Text, Text, Text> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");

        // key:委托索引
        // value:委托价格 委托数量 委托时间 买卖方向 Order_type + " o"（标注委托数据记号）
        context.write(new Text(fields[5]), new Text(String.join(",", Arrays.copyOfRange(fields, 0, 4)) + " o"));
    }
}
