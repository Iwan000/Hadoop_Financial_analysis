package mapper;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class Filter_Trade_Mapper extends Mapper<LongWritable, Text, Text, Text> {
    private Text filtered = new Text();
    private final String space = ",";

    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        //对逐行数据按"\t"分离
        String Line = value.toString();
        String[] split = Line.split("\t");

        if((!split[8].equals("000001")) ||//提取平安银行数据
                //过滤出所需时间段（连续竞价阶段）数据
                (Integer.parseInt(split[15].substring(8)) < 93000000) ||//连续竞价前
                ((Integer.parseInt(split[15].substring(8)) > 113000000)&&//午间停盘
                        (Integer.parseInt(split[15].substring(8)) < 130000000) )||
                (Integer.parseInt(split[15].substring(8)) > 145700000)){//收盘后
            return;
        }
        else {
            //委托时间(15) 委托价格(12) 委托数量(13) 买方索引(10) 卖方索引(11)
            filtered.set(split[15] + space + split[12] + space + split[13]
                    +space + split[10] + space + split[11]);
            context.write(new Text(split[14]), filtered);//成交类别(14)数值为4或F作为key
        }
    }
}
